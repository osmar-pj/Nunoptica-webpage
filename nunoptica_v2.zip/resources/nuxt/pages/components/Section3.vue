<template>
    <div class="container" id="tienda">
        <section class="section">
            <h1 class="title has-text-right has-text-azul">NOVEDADES</h1>
            <div class="columns is-vcentered">
                <div class="column is-6">
                    <p class="title">Variedad de lentes con tu estilo</p>
                    <div class="subtitle">
                        <p>Contamos con la más amplia variedad de los lentes con estilo para encontrar lo mas idóneo para tí, con protección filtro UV para cuidar tus ojos manteniendo la imagen que te siempre quisiste.</p>
                    </div>
                </div>
                <div class="column">
                    <div class="tile is-ancestor">
                        <div class="tile is-parent">
                            <article class="tile is-child">
                                <figure class="image is-1by2">
                                    <img src="../assets/pics/400x800_man_lentes.png" data-aos="flip-right">
                                </figure>
                            </article>
                        </div>
                        <div class="tile is-vertical">
                            <div class="tile is-parent">
                                <article class="tile is-child">
                                    <figure class="image is-1by1">
                                        <img src="../assets/pics/400x400_lentes_2.png" data-aos="flip-right">
                                    </figure>
                                </article>
                            </div>
                            <div class="tile is-parent">
                                <article class="tile is-child">
                                    <figure class="image is-1by1">
                                        <img src="../assets/pics/400x400_lentes_sol.png" data-aos="flip-right">
                                    </figure>
                                </article>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>