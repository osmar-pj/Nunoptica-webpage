<template>
    <div class="container" id="howWorks">
        <section class="section">
            <h1 class="title has-text-azul has-text-centered">COMO FUNCIONA</h1>
            <div class="columns">
                <div class="column">
                    <div class="card">
                        <div class="card-image" data-aos="zoom-in" data-aos-duration="1500">
                            <figure class="image is-1by1">
                                <img class="svg" src="../assets/svg/img_receta.svg">
                            </figure>
                        </div>
                        <div class="card-content">
                            <p class="has-text-centered has-text-oscuro">Envianos la receta medica a nuestro whatsApp obtenida en una clínica para ojos</p>
                        </div>
                    </div>
                </div>
                <div class="column">
                    <div class="card">
                        <div class="card-image" data-aos="zoom-in" data-aos-duration="1500">
                            <figure class="image is-1by1">
                                <img class="svg" src="../assets/svg/foto.svg">
                            </figure>
                        </div>
                        <div class="card-content">
                            <p class="has-text-centered has-text-oscuro">Envíanos una foto tuya de frente para que nuestro asesor de imagen con ayuda de nuestra inteligencia artificial sugiera los mejores modelos para ti.</p>
                        </div>
                    </div>
                </div>
                <div class="column">
                    <div class="card">
                        <div class="card-image" data-aos="zoom-in" data-aos-duration="1500">
                            <figure class="image is-1by1 ">
                                <img class="svg" src="../assets/svg/comprar.svg">
                            </figure>
                        </div>
                        <div class="card-content">
                            <p class="has-text-centered has-text-oscuro">Escoge los modelos seleccionados y realiza la compra, el precio incluye el costo por las lunas que requieres de acuerdo a tu receta médica</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>

<style lang="scss">
    .column {
        padding: 50px;
    }
    .svg {
        padding: 5rem;
    }
</style>