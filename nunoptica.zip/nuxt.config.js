const laravelNuxt = require("laravel-nuxt");
 
module.exports = laravelNuxt({
  // Your Nuxt options here...
  modules: [
    // Simple usage
    'nuxt-buefy',

    // Or you can customize
    ['nuxt-buefy', { css: false }],
  ],
  plugins: [],
 
  // Options such as mode, srcDir and generate.dir are already handled for you.
});