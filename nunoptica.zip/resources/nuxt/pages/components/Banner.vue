<template>
    <div class="is-fluid">
        <section class="hero is-claro is-large banner">
            <div class="hero-body">
                <div class="container has-text-centered">
                <h1 class="title is-size-1 has-text-claro">
                    LENTES CON <br>PERSONALIDAD
                </h1>
                <h2 class="subtitle has-text-claro">
                    Por que no somos sólo una tienda de óptica,<br> nosotros asesoramos tu imágen
                </h2>
                <br>
                <a href="" class="button is-primary is-large is-rounded">
                    <span class="icon">
                        <b-icon
                            icon="whatsapp"
                            type="is-claro"
                            size="is-medium">
                        </b-icon>
                    </span>
                    <span>+51 946252024</span>
                </a>
            </div>
            </div>
        </section>
    </div>
</template>

<style lang="scss">
    .banner {
        background-image: url('../assets/banner.png');
        background-repeat: no-repeat;
        background-size: cover;
        margin: -30px;
    }
</style>