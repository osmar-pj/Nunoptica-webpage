<template>
    <div class="is-fluid">
        <footer class="footer">
            <div class="content has-text-centered">
                <a href="#">
                    <img class="logo-negativo" src="../assets/svg/logo_negativo.png" alt="">
                </a>
                <div class="block">
                    <b-icon icon="whatsapp" size="is-medium" class="icon"></b-icon>
                    <b-icon icon="facebook" size="is-medium" class="icon"></b-icon>
                    <b-icon icon="linkedin" size="is-medium" class="icon"></b-icon>
                    <b-icon icon="instagram" size="is-medium" class="icon"></b-icon>
                </div>
                <p>Powered by <a href=""><span>GUNJOP!</span> </a> COMPANY</p>
            </div>
        </footer>
    </div>
</template>

<style lang="scss">
    .icon {
        margin: 0 20px;
    }
    .footer {
        background: rgb(17,29,94);
        background: linear-gradient(148deg, rgba(17,29,94,1) 39%, rgba(199,0,57,1) 100%);
    }
    .logo-negativo {
        padding: 2rem;
    }
</style>